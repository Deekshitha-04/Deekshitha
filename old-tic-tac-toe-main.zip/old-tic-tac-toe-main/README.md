# old-tic-tac-toe

## wrote it back when I was in college

### single file vanilla javascript, html, css

![ezgif com-gif-maker (8)](https://user-images.githubusercontent.com/19613367/117716755-9a60b680-b1f7-11eb-988b-c55809b64041.gif)
